export const fadePresence = {
    initial: {opacity: 0},
    exit: {opacity: 0},
    animate: {opacity: 1},
    transition: {duration: .3, ease: 'easeIn'}
}