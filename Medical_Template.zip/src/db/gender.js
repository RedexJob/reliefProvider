export const y2019 = [
    {
        name: 'January',
        men: 220,
        women: 350
    },
    {
        name: 'February',
        men: 185,
        women: 214
    },
    {
        name: 'March',
        men: 294,
        women: 305
    },
    {
        name: 'April',
        men: 199,
        women: 214
    },
    {
        name: 'May',
        men: 374,
        women: 300
    },
    {
        name: 'June',
        men: 288,
        women: 265
    },
    {
        name: 'July',
        men: 355,
        women: 200
    },
    {
        name: 'August',
        men: 218,
        women: 301
    },
    {
        name: 'September',
        men: 180,
        women: 250
    },
    {
        name: 'October',
        men: 274,
        women: 145
    },
    {
        name: 'November',
        men: 387,
        women: 218
    },
    {
        name: 'December',
        men: 281,
        women: 311
    },
];

export const y2020 = [
    {
        name: 'January',
        men: 311,
        women: 205
    },
    {
        name: 'February',
        men: 283,
        women: 344
    },
    {
        name: 'March',
        men: 381,
        women: 240
    },
    {
        name: 'April',
        men: 199,
        women: 288
    },
    {
        name: 'May',
        men: 374,
        women: 300
    },
    {
        name: 'June',
        men: 511,
        women: 250
    },
    {
        name: 'July',
        men: 399,
        women: 200
    },
    {
        name: 'August',
        men: 366,
        women: 415
    },
    {
        name: 'September',
        men: 220,
        women: 180
    },
    {
        name: 'October',
        men: 155,
        women: 280
    },
    {
        name: 'November',
        men: 480,
        women: 355
    },
    {
        name: 'December',
        men: 300,
        women: 220
    },
];

export const y2021 = [
    {
        name: 'January',
        men: 566,
        women: 309
    },
    {
        name: 'February',
        men: 283,
        women: 344
    },
    {
        name: 'March',
        men: 381,
        women: 240
    },
    {
        name: 'April',
        men: 340,
        women: 220
    },
    {
        name: 'May',
        men: 374,
        women: 300
    },
    {
        name: 'June',
        men: 200,
        women: 250
    },
    {
        name: 'July',
        men: 399,
        women: 200
    },
    {
        name: 'August',
        men: 366,
        women: 415
    },
    {
        name: 'September',
        men: 220,
        women: 180
    },
    {
        name: 'October',
        men: 155,
        women: 280
    },
    {
        name: 'November',
        men: 480,
        women: 355
    },
    {
        name: 'December',
        men: 500,
        women: 600
    },
];

export const y2022 = [
    {
        name: 'January',
        men: 303,
        women: 260
    },
    {
        name: 'February',
        men: 283,
        women: 344
    },
    {
        name: 'March',
        men: 400,
        women: 350
    },
    {
        name: 'April',
        men: 340,
        women: 220
    },
    {
        name: 'May',
        men: 374,
        women: 300
    },
    {
        name: 'June',
        men: 200,
        women: 250
    },
    {
        name: 'July',
        men: 399,
        women: 200
    },
    {
        name: 'August',
        men: 366,
        women: 415
    },
    {
        name: 'September',
        men: 220,
        women: 180
    },
    {
        name: 'October',
        men: 155,
        women: 280
    },
    {
        name: 'November',
        men: 202,
        women: 140
    },
    {
        name: 'December',
        men: 70,
        women: 140
    },
];