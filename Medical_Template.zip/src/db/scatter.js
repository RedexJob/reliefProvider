export const y2020 = [
    {men: 120, women: 216, children: 50},
    {men: 85, women: 180, children: 40},
    {men: 155, women: 281, children: 12},
    {men: 193, women: 220, children: 23},
    {men: 110, women: 311, children: 67},
    {men: 94, women: 122, children: 10},
    {men: 214, women: 455, children: 80},
    {men: 118, women: 315, children: 90},
    {men: 407, women: 536, children: 21},
    {men: 117, women: 205, children: 44},
    {men: 280, women: 148, children: 95},
    {men: 125, women: 302, children: 87},
];

export const y2021 = [
    {men: 168, women: 270, children: 15},
    {men: 165, women: 217, children: 56},
    {men: 298, women: 394, children: 105},
    {men: 390, women: 440, children: 146},
    {men: 480, women: 305, children: 180},
    {men: 260, women: 203, children: 18},
    {men: 404, women: 202, children: 25},
    {men: 518, women: 400, children: 90},
    {men: 366, women: 256, children: 10},
    {men: 114, women: 333, children: 180},
    {men: 400, women: 150, children: 99},
    {men: 280, women: 356, children: 41},
];

export const y2022 = [
    {men: 384, women: 502, children: 211},
    {men: 222, women: 184, children: 69},
    {men: 287, women: 405, children: 356},
    {men: 390, women: 100, children: 150},
    {men: 500, women: 120, children: 305},
    {men: 313, women: 456, children: 202},
    {men: 102, women: 211, children: 145},
    {men: 365, women: 647, children: 13},
    {men: 666, women: 333, children: 222},
    {men: 444, women: 222, children: 111},
    {men: 366, women: 422, children: 305},
    {men: 125, women: 302, children: 87},
];