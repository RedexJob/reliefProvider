export const year = [
    {cured: 314, sick: 170},
    {cured: 200, sick: 240},
    {cured: 265, sick: 400},
    {cured: 156, sick: 210},
    {cured: 412, sick: 300},
    {cured: 504, sick: 200},
    {cured: 311, sick: 600},
    {cured: 300, sick: 80},
    {cured: 156, sick: 210},
    {cured: 412, sick: 300},
    {cured: 156, sick: 550},
    {cured: 412, sick: 140},
]

export const month = [
    {cured: 360, sick: 210},
    {cured: 380, sick: 250},
    {cured: 400, sick: 320},
    {cured: 450, sick: 190},
    {cured: 300, sick: 450},
    {cured: 350, sick: 220},
    {cured: 400, sick: 500},
    {cured: 380, sick: 150},
    {cured: 250, sick: 330},
    {cured: 450, sick: 250},
    {cured: 350, sick: 400},
    {cured: 500, sick: 200},
]

export const week = [
    {cured: 400, sick: 250},
    {cured: 280, sick: 200},
    {cured: 420, sick: 190},
    {cured: 310, sick: 180},
    {cured: 330, sick: 210},
    {cured: 380, sick: 200},
    {cured: 250, sick: 500},
    {cured: 220, sick: 378},
    {cured: 280, sick: 180},
    {cured: 394, sick: 200},
    {cured: 90, sick: 351},
    {cured: 154, sick: 110},
]